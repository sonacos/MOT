import React from 'react';

// This component is obsolete and has been merged into FinalReportView.
const ReportView: React.FC = () => null;

export default ReportView;